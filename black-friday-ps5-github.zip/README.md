# Odliczanie do Black Friday – zakup PS5

Prosta strona z odliczaniem do Black Friday 2026 (27 listopada 2026).

## Publikacja przez GitHub Pages
1. Utwórz nowe repozytorium na GitHubie.
2. Wgraj plik `index.html` do głównego katalogu repozytorium.
3. Wejdź w **Settings → Pages**.
4. W sekcji **Build and deployment** wybierz **Deploy from a branch**.
5. Wybierz branch `main` i folder `/ (root)`, a następnie kliknij **Save**.
6. Po chwili GitHub pokaże adres opublikowanej strony w ustawieniach Pages.
